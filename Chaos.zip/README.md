# Chaos
Python application for simulating deterministic chaos on the example of Lorenz and Roessler systems. 
